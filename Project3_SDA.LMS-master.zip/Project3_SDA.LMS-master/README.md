# Project3_SDA.LMS

SDA_simplilearn Assessment Project3, Phase3: Database Connectivity and Web Services Using ASP .NET ASP.NET MVC
web application for (eCommerce Story, Laptops Market), that store(ADD), Retrieve, Edit and delete data.


## App overview :

![1](https://user-images.githubusercontent.com/59418749/133458243-b7cdb5a9-b0c6-4887-8ba7-e9895573ca0b.jpg)


![3](https://user-images.githubusercontent.com/59418749/133458561-7a27fa48-d6e1-4b15-be77-51db2b356aee.jpg)
